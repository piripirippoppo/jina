package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;
import model.*;

public class StudentTests 
{
	int indentation = 3;
	String strIndent = "";
	String attributes = null;
	
	@Test
	public void Texttest() 
	{
		for(int i=0; i<indentation; i++)
			strIndent += " ";
		
		String testText1 = "Good morning";
		String testText2 = "How are you?";
		
		TagElement.enableId(false);
		TagElement.resetIds();
		
		Element textE1 = new TextElement(testText1);
		TextElement textE2 = new TextElement(testText2);
		
		assertEquals(strIndent+testText1, textE1.genHTML(indentation));
		assertEquals(textE2.genHTML(indentation), strIndent+testText2);
	}
	
	@Test
	public void Headingtest()
	{
		for(int i=0; i<indentation; i++)
			strIndent += " ";
		int level=3;
		
		String startTag="<h"+level+">";
		String endTag="</h"+level+">";
		
		TagElement.enableId(false);
		TagElement.resetIds();
		
		String testHeading1 = "Having fun?";
		String testHeading2 = "I am fine. Thank you";
		String result1 = strIndent+startTag+testHeading1+endTag;
		String result2 = strIndent+startTag+testHeading2+endTag;
		//HeadingElement(Element content, int level, String attributes)
		Element headingE1 = new HeadingElement(new TextElement(testHeading1), level, null);
		Element headingE2 = new HeadingElement(new TextElement(testHeading2), level, null);
		System.out.println(result1);
		System.out.println(headingE1.genHTML(indentation));
		assertEquals(result1, headingE1.genHTML(indentation));
		assertEquals(result2, headingE2.genHTML(indentation));
	}
	
	@Test
	public void anchortest()
	{
		for(int i=0; i<indentation; i++)
			strIndent += " ";

		String url="www.umd.edu"; String linkText="Welcome to UMD";
		
		String startTag="<a href=";
		String endTag="</a>";
		
		TagElement.enableId(false);
		TagElement.resetIds();
		
		String result1 = strIndent+startTag+"\""+url+"\""+">"+linkText+endTag;
		//String url, String linkText, String attributes
		Element anchorE1 = new AnchorElement(url, linkText, attributes);
		
		System.out.println(anchorE1.genHTML(indentation));
		System.out.println(result1);
		assertEquals(result1, anchorE1.genHTML(indentation));	
	}
	
	@Test
	public void Tabletest()
	{
		for(int i=0; i<indentation; i++)
			strIndent += " ";
		String result = strIndent+"<table id=\"table1\" border=\"1\">\n"+
				strIndent+strIndent+"<tr><td>hola</td><td>halo</td></tr>\n"+
				strIndent+strIndent+"<tr><td>hello</td><td></td></tr>\n"+
				"   </table>";
		
		TagElement.enableId(true);
		TableElement tableE = new TableElement(2, 2, "border=\"1\"");
		
		tableE.addItem(0, 0, new TextElement("hola"));
		tableE.addItem(0, 1, new TextElement("halo"));
		tableE.addItem(1, 0, new TextElement("hello"));
		//tableE.addItem(1, 1, new TextElement("ohayo"));
		//System.out.println(tableE.genHTML(indentation));
		System.out.print(result);
		assertEquals(result, tableE.genHTML(indentation));
		
	}
}

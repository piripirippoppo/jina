package model;

public interface Element 
{
	String genHTML(int indentation);
}
